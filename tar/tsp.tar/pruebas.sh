#!/bin/bash
#forma de ejecutar el comando:
#	./comando Parametro1 Parametro2 Parametro3 Parametro4 Parametro5 Parametro6
#	Parametro1 -> Algoritmo de ejecucion del fichero tsp mirar readme de ejecucion para comprobar las opciones [ -all -fb -av -pd -rp]
#	Parametro2 -> Tamanio de inicio o base de los ficheros a comprobar ./pruebas 10 -> ejecutara el fichero a10.tsp 
#	Parametro3 -> 1 Generar nuevos ficheros con el tamanio descrito en la Parametro2 0 Utiliza el fichero aParametro2.tsp de la misma carpeta
#	Parametro4 -> Iteraciones o numero de pruebas a realizar. 0...Parametro4
#	Parametro5 -> 0 para indicar que el tamanio de las pruebas no incrementa o cualquier otro valor que sera el incremento a la base colocada en el Parametro2 
#	Parametro6 -> 0 Guarda el resultado en aParametro2.solve o Cualquier valor esto introducira los resultados en un unico fichero aParametro6.solve
#
#comando tipoEjecucion[-all -pd..] tamanioTSP nuevos[1 | 0] NumeroPruebas incremental[0 | ValorIncremental] UnicFile[0 | nombreFichero]
#Example of use ./pruebas -all 12 1 5 0 0 //hara 5 pruebas creando 5 ficheros diferentes de tamanio 12 con todos algoritmos
#Example of use ./pruebas -all 12 1 5 5 0 //hara 5 pruebas creando 5 ficheros diferentes de tamanio incremental al ultimo valor
#con todos algoritmos base 12 + 5 




iteraciones=0;
limite=$4;
fichero=$2;
while [ $iteraciones -ne $limite ]; do
	if [ $3 -eq 1 -a $5 -eq 0 ]; then
		./generadorTSP $fichero
	fi
	if [ $5 -ne 0 ]; then
		fichero=$((fichero+$5))
		./generadorTSP $fichero
	fi
	if [ "$6" != 0 ]; then
		./tsp "$1" a"$fichero".tsp >> a"$6".solve
	else
		./tsp "$1" a"$fichero".tsp >> a"$fichero".solve	
	fi
	iteraciones=$((iteraciones+1));
done
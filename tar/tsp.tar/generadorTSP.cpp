#include <iostream>
#include <fstream>
#include <random>
#include <cstdlib>
#include <iomanip>

using namespace std;

int MIN = 1;
int MAX = 100;

int main(int argc, char ** argv) {
    random_device rd;
    default_random_engine realAleatorio(rd());
    uniform_real_distribution<double> generador(MIN, MAX);


    int tamanio;


    if(argc == 2) {
        tamanio = atoi(argv[1]);
    }
    else {
        cout << "Introduzca un tamanyo para generar un problema tsp: " << flush;
        cin >> tamanio;
    }
    ofstream fichero;

    string nombre = "a" + to_string(tamanio) + ".tsp";
    fichero.open(nombre);

    double numero;
    for (int i = 0; i < tamanio; ++i) {
        for (int j = 0; j < tamanio; ++j) {
            if (i == j){
                numero = 0;
            }else{
                numero = generador(realAleatorio);
            }
            fichero << setprecision(3) << numero << " ";
        }
        fichero << "\n";
    }

    return 0;
}
